#ifndef __LIST1_H__
#define __LIST1_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node
{
	int socketfd;
	char user_ip[50];
    char user_name[50];
    short port;
	struct Node *prev, *next;
} node, *list;




//extern int arrlen1 ;
//extern int arrlen2 ;
list init_list(void);
list newNode(char *user_ip, char *user_name, short port, int socketfd);
void list_add_tail(list new,list head);
void list_delete_tail(list new);


#endif
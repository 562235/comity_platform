#ifndef __LCD_H__
#define __LCD_H__

/*********************** 头文件 ***********************/
#include <stdio.h>   	
#include <fcntl.h>		 	 
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdlib.h>

#include "jpeglib.h"
/*********************** 宏定义 ***********************/
#define LCD_WIDTH  			800
#define LCD_HEIGHT 			480
#define FB_SIZE				(LCD_WIDTH * LCD_HEIGHT * 4)


/*********************** 全局变量 ***********************/
/* video_chat.c 画中画显示的坐标 */
extern volatile int g_jpg_in_jpg_x;
extern volatile int g_jpg_in_jpg_y;

/*********************** 函数声明 ***********************/


#endif
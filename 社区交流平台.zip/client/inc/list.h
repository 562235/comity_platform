#ifndef __LIST_H__
#define __LIST_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct Node
{
	char user_ip[50];
    char user_name[50];
    short port;
	struct Node *prev, *next;
} node, *list;

typedef struct Node_tcp
{
	char user_ip[50];
    int sockfd;
    short port;
	struct Node_tcp *prev, *next;
} node_tcp, *list_tcp;


//extern int arrlen1 ;
//extern int arrlen2 ;
list init_list(void);
list_tcp init_list_tcp(void);
list newNode(char *user_ip, char *user_name, short port);
void list_add_tail(list new,list head);
void list_add_tail_tcp(list_tcp new,list_tcp head);
void list_delete_tail(list new);
void list_delete_tail_tcp(list_tcp new);
list_tcp newNode_tcp(char *user_ip, int sockfd, short port);

#endif
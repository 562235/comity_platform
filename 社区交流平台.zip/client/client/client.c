#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> 
#include <sys/types.h>          /* See NOTES */
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <strings.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "font.h"

#define MAX 1024

struct LcdDevice* lcd;
/* 
 *函数功能:打印通知到显示屏上
 */
void *inform_show(char *inform_msg)
{
	
 	//接收通知内容
    char msg1[100] = {0};
    printf("通知：%s\n", inform_msg);
    //-------------------------打开字体	
	font *f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	//字体大小的设置
	fontSetSize(f,28);
    //创建画板（点阵图）
	bitmap *bm = createBitmapWithInit(400,200,4,getColor(0,0,139,0));
	//如果字数超过一行，则另起一行
	if(strlen(inform_msg) > 57)
    {
    	strcpy(msg1, inform_msg+57);
    	//将字体显示在字体框
		fontPrint(f,bm,0,0,"通知：",getColor(0,255,255,255),0);
		fontPrint(f,bm,0,28,inform_msg,getColor(0,255,255,255),0);
		fontPrint(f,bm,0,56,msg1,getColor(0,255,255,255),0);
		//在屏幕上刷出字体框
		show_font_to_lcd(lcd->mp,400,0,bm);
    }
    else
    {
    	//将字体显示在字体框
		fontPrint(f,bm,0,0,"通知：",getColor(0,255,255,255),0);
		fontPrint(f,bm,0,28,inform_msg,getColor(0,255,255,255),0);
		//在屏幕上刷出字体框
		show_font_to_lcd(lcd->mp,400,0,bm);
    }
   
}
/*
 *函数功能：用于下载广告图片
 */
void *pic_download(char *arg)
{
	//创建一个用于访问自己服务器的套接字
	int pic_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(pic_socket < 0)
	{
		perror("pic_socket create failed");
		return NULL;
	}
 	//创建用于访问自己服务器的地址信息
	struct sockaddr_in weather_addr;
	weather_addr.sin_family = AF_INET;
	weather_addr.sin_addr.s_addr = inet_addr("192.168.95.2");
	weather_addr.sin_port = htons(80);
	//连接服务器
	int ret = connect(pic_socket, (struct sockaddr *)&weather_addr, sizeof(weather_addr));
	if(ret >= 0)
	{
		printf("连接成功\n");
	}
	if(ret < 0)
	{
		perror("connect failed");
		close(pic_socket);
		return NULL;
	}
	//找到指定的图片
	char http[1024] = {0};
	sprintf(http, "GET /photo/%s HTTP/1.1\r\nHost:192.168.95.2\r\n\r\n", arg);
	//将头请求写给服务器
	ret = write(pic_socket, http, strlen(http));
	char pic_name[100] = {0};
	//打开当前目录下的图片
	sprintf(pic_name, "./%s", arg);
	int fd = open(pic_name, O_RDWR|O_CREAT|O_TRUNC, 0777);
	if(fd == -1)
	{
		perror("open file failed");
		return NULL;
	}

	//找到头数据
	char buf[MAX] = {0};
	int headlen = 0, filelen = 0, sum = 0;
	int size = read(pic_socket, buf, MAX);

	//找到头数据结束符
	char *p = strstr(buf, "\r\n\r\n");
	if(p != NULL)
	{
		headlen = (int)((p+4)-buf);
		printf("%d\n", headlen );
	}

	//找到文件大小
	char *file = strstr(buf, "Content-Length:");
	if(file != NULL)
	{
		//将文件大小字符串转为整型
		filelen = atoi(file+15);
		printf("图片大小为:%d\n", filelen);
	}
	//将图片数据写到本地文件中
	write(fd, p+4, size - headlen);
	sum += size - headlen;
	
	//传剩下的数据 如果sum等于文件大小 关完就走
	while(1)
	{	
		bzero(buf, MAX);
		size = read(pic_socket, buf, MAX);
		write(fd, buf, size);
		sum += size;
		if(sum == filelen)
		{
			printf("图片传输完毕\n");
			break;
		}
	}
	
}

/*
 *函数功能：用于更新广告图片名称
 */
 void *pic_updata(void *arg)
 {
 	//创建UDP通信socket 
    int udp_socket = *((int *)arg);

	//udp通信的地址信息及大小 用户连接UDP广播
	struct sockaddr_in   bro_addr, udp_addr; 
    bro_addr.sin_family  = AF_INET;
    bro_addr.sin_port    = htons(9898); 
    bro_addr.sin_addr.s_addr = inet_addr("255.255.255.255");
    int size = sizeof(bro_addr);

    while(1)
    {
    	//用于接收整个信息
	    char buf[MAX] = {0};
	    //存放信息类型
	    char type[100] = {0};
	    //存放图片名称
	    char msg[200] = {0};
	    recvfrom(udp_socket, buf, MAX, 0, (struct sockaddr *)&udp_addr, &size);
	    //分割信息
	    sscanf(buf, "type=%s msg=%s", type, msg);
	    if(strcmp(type, "pic_updata") == 0)
	    {
	    	//正在下载图片，关闭取消请求
	    	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
	    	printf("本次要更新的图片名:%s\n", msg);
	    	//从服务器中下载指定图片
	    	pic_download(msg);
	    	lcd_draw_jpg(0, 0, msg, NULL, 0, 0);
	    	//执行完，开启取消请求
	    	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	    }
	    //通知类型 执行该代码
	    if(strcmp(type, "inform") == 0)
	    {
	    	//正在执行，关闭取消请求
	    	pthread_setcancelstate(PTHREAD_CANCEL_DISABLE, NULL);
	    	inform_show(msg);
	    	//执行完，开启取消请求
	    	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
	    }
	    

    }
    
 }

/*
 *函数功能：用于实时获取天气
 *
 */
void *weather(void *arg)
{
	//创建http_socke TCP通信socket 专用与获取天气
	int http_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(http_socket < 0)
	{
		perror("http_socket create failed");
		return NULL;
	}	//创建用于访问天气aip的地址信息
	struct sockaddr_in weather_addr;
	weather_addr.sin_family = AF_INET;
	weather_addr.sin_addr.s_addr = inet_addr("47.107.120.234");
	weather_addr.sin_port = htons(80);

	//连接指定天气地址
	int ret = connect(http_socket, (struct sockaddr *)&weather_addr, sizeof(weather_addr));
	if(ret >= 0)
	{
		printf("连接成功\n");
	}
	if(ret < 0)
	{
		perror("connect failed");
		close(http_socket);
		return NULL;
	}

	//-------------------------打开字体	
	font *f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	//字体大小的设置
	fontSetSize(f,30);

	while(1)
	{
		//访问指定地址，获取天气信息
		char *http = "GET /api.php?key=free&appid=0&msg=广州天气 HTTP/1.1\r\nHost:api.qingyunke.com\r\n\r\n";

		ret = write(http_socket, http, strlen(http));
		//找到头数据
		char buf[MAX] = {0};
		int headlen = 0, filelen = 0;
		int size = read(http_socket, buf, MAX);

		//找到有效信息
		char *p = strstr(buf, "content");
		if(p != NULL)
		{
			headlen = (int)((p+10)-buf);
		}

		//找到服务器返回的文件大小
		char *file = strstr(buf, "Content-Length:");
		if(file != NULL)
		{
			//将文件大小字符串转为整型
			filelen = atoi(file+16);
		}
		//为了美观 去除掉末尾的符号
		char *tail = strstr(buf, "}");
		if(tail != NULL)
		{
			memset(tail-1, 0, 2);
		}
		//打印， 只要有效信息
		printf("%s\n", p+10);
		
		//创建画板（点阵图）
		bitmap *bm = createBitmapWithInit(800,32,4,getColor(0,0,0,0));
		//将字体显示在字体框
		fontPrint(f,bm,0,0,p+10,getColor(0,255,255,255),0);
		//在屏幕上刷出字体框
		show_font_to_lcd(lcd->mp,0,480-32,bm);

		//每30秒获取一次天气
		sleep(30);
	}

}
/*
 *函数功能：用于接收别人的聊天信息
 */
 void *talk_func(void *arg)
 {
 	int tcp_sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(tcp_sockfd < 0)
    {
        perror("Create socket failed ");
        return NULL;
    }
    //设置tcp服务器地址信息
    struct sockaddr_in serveraddr,clientaddr;
    clientaddr.sin_family = AF_INET;               //IPV4的协议族
    clientaddr.sin_addr.s_addr = inet_addr("192.168.95.2");       //任何IPV4的地址都可以链接
    clientaddr.sin_port = htons(8989);
    int size = sizeof(clientaddr);
 	
 	int ret = connect(tcp_sockfd, (struct sockaddr *)&clientaddr, size);
 	if(ret == -1)
 	{
 		perror("connect failed");
 		return NULL;
 	}
 	//不断接收信息并显示出来
 	while(1)
 	{
 		char buf[4096] = {0};
	 	char type[100] = {0};
	 	//char talk_obj[100] = {0};
	 	char talk_msg[1024] = {0};
 		//接收聊天信息
 		read(tcp_sockfd, buf, 4096);
 		sscanf(buf, "type=%s msg=%s", type, talk_msg);
 		//如果是聊天内容，则打印出来
 		if(strcmp(type, "chat_message") == 0)
 		{
 			printf("%s\n", talk_msg);
 		}

 	}
 	
 }


int main(int argc, char const *argv[])
{
	//创建UDP 通信socket  
    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if(udp_socket < 0)
	{
		perror("udp_socket create failed");
		return -1;
	}

	//创建TCP 通信socket
	int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(tcp_socket < 0)
	{
		perror("tcp_socket create failed");
		return -1;
	}
	//初始化Lcd
	lcd = init_lcd("/dev/fb0");

    int on=1; //开启广播
    int ret = setsockopt(udp_socket,SOL_SOCKET,SO_BROADCAST,&on,sizeof(on));
        if(ret <0)
        {
            perror("广播失败：");
            return -1;
        }
        else
            printf("开启广播成功\n");

	//udp通信的地址信息及大小 
	struct sockaddr_in   udp_addr, test_addr; 
    udp_addr.sin_family  = AF_INET;
    udp_addr.sin_port    = htons(9898); 
    udp_addr.sin_addr.s_addr = inet_addr("0.0.0.0");
    int size = sizeof(udp_addr);

    //3.设置广播地址  192.168.94.255  or  255.255.255.255 
	struct sockaddr_in   bro_addr; 
    bro_addr.sin_family  = AF_INET;
    bro_addr.sin_port    =  htons(9898); 
    bro_addr.sin_addr.s_addr = inet_addr("255.255.255.255"); 

    ret = bind(udp_socket,(struct sockaddr *)&udp_addr, size);
    if(ret == -1)
    {
    	perror("bind falied");
    	return -1;
    }
    //向广播中发送上线通知
    char buf[MAX] = {0};
    char name[100] = {0};
    printf("请输入你的大名\n");
    fflush(stdin);
    scanf("%s", name);
    sprintf(buf, "type=shangxian msg=%s", name);
    sendto(udp_socket,buf,strlen(buf),0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));

    //创建线程
    pthread_t pid, pid1, pid2;
    //天气线程
    pthread_create(&pid, NULL, weather, NULL);
    //图片更新下载及通知显示线程
    pthread_create(&pid1, NULL, pic_updata, (void *)&udp_socket);
    //用于接收别人给你的聊天内容
    pthread_create(&pid1, NULL, talk_func, (void *)&udp_socket);

    //-打开字体	显示聊天
	font *f = fontLoad("/usr/share/fonts/DroidSansFallback.ttf");
	//字体大小的设置
	fontSetSize(f,32);
	//创建画板（点阵图）
	bitmap *bm = createBitmapWithInit(80,60,4,getColor(0,255,228,181));
	//将字体显示在字体框
	fontPrint(f,bm,10,10,"聊天",getColor(0,255,255,255),0);
	//在屏幕上刷出字体框
	show_font_to_lcd(lcd->mp,720,350,bm);


    while(1)
    {
    	int a = 0;
    	printf("聊天请按1，下线请按2\n");
    	fflush(stdin);
    	if(scanf("%d", &a) != 1)
    	{
    		printf("请输入1或者2\n");
    		continue;
    	}
    	if(a == 1)
    	{
    		//点击聊天后才能通信
    		int click = -1;
    		if(click != 0)
    		{
    			click = touchScreen();
    		}
    		//存放在线列表
    		char *name_list[10] = {0};
    		//存放用户名信息
    		char name_msg[1024] = {0};
    		//在线的有多少人
    		int num = 0;
    		//用来偏移用户
    		int i = 0;
    		//消息类型
    		char type[100] = {0};
    		bzero(buf, MAX);
    		sprintf(buf, "type=request_list msg=%s", name);
    		//请求服务器发送在线名单
    		sendto(udp_socket,buf,strlen(buf),0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));
    		recvfrom(udp_socket, buf, 4096, 0, (struct sockaddr *)&test_addr, &size); 
      		//sendto(udp_socket,"ok",2,0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));
      		sscanf(buf, "type=%s msg=%s num=%d", type, name_msg, &num);
    		sendto(udp_socket,buf,strlen(buf),0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));
    		//等待服务器返回在线列表
    		while(1)
    		{
    			
    			bzero(buf, MAX);
    			if(strcmp(type, "back_user_list") == 0)
      				break;
    			//接收信息
      			recvfrom(udp_socket, buf, 4096, 0, (struct sockaddr *)&test_addr, &size);printf("1111111111\n");
      			//sendto(udp_socket,"ok",2,0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));
      			sscanf(buf, "type=%s msg=%s num=%d", type, name_msg, &num);
      		
      			
    		}
    		
    		//如果只有自己则退出
    		if(num == 1)
    		{
    			printf("当前在线用户只有我一个\n");
    			continue;
    		}
    		//如果有别人 则获取信息
    		else if( num > 1)
    		{
    			char *flag = name_msg;
    			//字符串分割
    			while( flag != NULL)
    			{
    				name_list[i++] = strsep(&flag, "&");
    			}
    		}
    		i = 0;
    		//字体框坐标
    		int x = 400, y = 200;
    		//在屏幕上显示在线列表
    		while(name_list[i] != NULL)
    		{ 			
    			//创建画板（点阵图）
				bitmap *bm = createBitmapWithInit(100,60,4,getColor(0,255,228,181));
				//将字体显示在字体框
				fontPrint(f,bm,10,10,name_list[i],getColor(0,255,255,255),0);
				//在屏幕上刷出字体框
				show_font_to_lcd(lcd->mp,x,y,bm);
				x += 100;
				if(x >= 800)
					y += 60;
				i++;
    		}
    		//点击对应名字进行通信
    		printf("请点击你要通信的人\n");
    		click = touchScreen();
    		//输入你要说的信息
    		printf("输入你要说的信息\n");
    		char my_talk[1024] = {0};
    		//清空输入缓冲区
    		fflush(stdin);
    		scanf("%s", my_talk);
    		//清空buf，为等下的发送做准备
    		bzero(buf, MAX);
    		sprintf(buf, "type=talk_msg msg=%s&obj=%s", my_talk, name_list[click-1]);
    		printf("%s\n", buf);
    		//发送消息和通信对象给服务器
    		sendto(udp_socket,buf,strlen(buf),0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));

    	}
    	if(a == 2)
    	{
    		//取消pid线程
    		pthread_cancel(pid);
    		pthread_join(pid, NULL);
    		//取消pid1线程
    		pthread_cancel(pid1);
    		//尝试取消线程pid1，如果在工作则持续取消请求
    		while(pthread_tryjoin_np(pid1, NULL) != 0 )
    			pthread_cancel(pid1);
    		//销毁字体
    		fontUnload(f);
    		//关闭画板
    		destroyBitmap(bm);
    		char cancel_msg[MAX] = {0};
    		//发送下线通知
    		sprintf(cancel_msg, "type=xiaxian msg=%s", name);
    		sendto(udp_socket,cancel_msg,strlen(cancel_msg),0,(struct sockaddr *)&bro_addr,sizeof(bro_addr));
    		return 0;
    	}
    }


	return 0;
}
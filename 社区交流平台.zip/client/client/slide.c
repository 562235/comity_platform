#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/input.h>


#define talk x>720 && x < 800 && y > 350 && y < 410
#define user1 x>400 && x < 500 && y > 200 && y < 260
#define user2 x>500 && x < 600 && y > 200 && y < 260
#define user3 x>600 && x < 700 && y > 200 && y < 260

/*用于滑动函数的变量*/
int ts_fd;

//滑动的距离必须大于150个像素
//返回值： 0 左滑   1 右滑   2 下滑   -1 不满足任何滑动条件
int ts_slide()
{
	//read函数第一次返回的x和第一次返回的y就是begin_x和begin_y
	int begin_x, begin_y;
	int end_x, end_y;

	int flag_x = 0;//0代表还未还未进行第一次读取 1代表已经进行了第一次读取
	int flag_y = 0;


	struct input_event ev;
	ts_fd = open("/dev/input/event0", O_RDONLY);
	if(ts_fd == -1)
	{
		printf("open ts failed\n");
	}
	while(1)
	{
		read(ts_fd, &ev, sizeof(ev));//在读取触摸屏文件的时候是阻塞的
		if(ev.type == EV_ABS && ev.code == ABS_X)
		{
			if(flag_x == 0)
			{
				begin_x = ev.value;
				flag_x = 1;
			}

			end_x = ev.value;
		}

		if(ev.type == EV_ABS && ev.code == ABS_Y)
		{
			if(flag_y == 0)
			{
				begin_y = ev.value;
				flag_y = 1;
			}

			end_y = ev.value;
		}

		if(ev.type == EV_KEY && ev.code == BTN_TOUCH && ev.value == 0)//手指抬起
		{
			break;
		}
	}


	if(begin_x - end_x >= 150)//左滑
	{
		return 0;
	}

	if(end_x - begin_x >= 150)//右滑
	{
		return 1;
	}

	if(end_y - begin_y >= 150)//下滑
	{
		return 2;
	}

	close(ts_fd);
	return -1;

}

int touchScreen()
{
	struct input_event ts;
	int x,y;
	int fs = open("/dev/input/event0", O_RDONLY);
	if(fs == -1)
	{
		perror("open ts failed");
	}
	while(1)
	{
		read(fs,&ts,sizeof(ts));
	
		if(ts.type == EV_ABS  && ts.code == ABS_X){
			x=ts.value;
		}
		
		if(ts.type == EV_ABS  && ts.code == ABS_Y){
			y=ts.value;
		}
		
		if( ts.type == EV_KEY && ts.code == BTN_TOUCH && ts.value == 0 ){
			/*手指离开触摸屏时刻 x，y的数值*/
			if(talk)
			{
				return 0;
			}
			if(user1)
			{
				return 1;
			}
			if(user2)
			{
				return 2;
			}
			if(user3)
			{
				return 3;
			}

		}
	}
	close(fs);
}


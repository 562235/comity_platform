#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "list.h"

/*
 *函数名：init_list
 *函数功能：初始化头节点
 *参数：void
 *返回值：list
 */
list init_list()
{
	list head = malloc(sizeof(node));
	if(head != NULL)
	{
		head->prev = head;
		head->next = head;
	}
	return head;
}
/*
 *函数名：init_list_tcp
 *函数功能：初始化头节点
 *参数：void
 *返回值：list
 */
list_tcp init_list_tcp()
{
	list_tcp head = malloc(sizeof(node));
	if(head != NULL)
	{
		head->prev = head;
		head->next = head;
	}
	return head;
}

/*
 *函数名：newNode
 *函数功能：初始化新节点
 *参数：void
 *返回值：list
 */
list newNode(char *user_ip, char *user_name, short port)
{
	list new = malloc(sizeof(node));
	if(new != NULL)
	{
		strcpy(new->user_ip, user_ip);
		strcpy(new->user_name, user_name);
		new->port = port;
		new->prev = NULL;
		new->next = NULL;
		return new;
	}

	return new;
}

/*
 *函数名：newNode
 *函数功能：初始化新节点
 *参数：void
 *返回值：list
 */
list_tcp newNode_tcp(char *user_ip, int sockfd, short port)
{
	list_tcp new = malloc(sizeof(node));
	if(new != NULL)
	{
		strcpy(new->user_ip, user_ip);
		new->sockfd = sockfd;
		new->port = port;
		new->prev = NULL;
		new->next = NULL;
		return new;
	}

	return new;
}

/*
 *函数名：list_add_tail
 *函数功能：将新节点链接到链表最后
 *参数：list new,list head
 *返回值：void
 */
void list_add_tail(list new,list head)
{
	new->next = head;
	new->prev = head->prev;
	
	head->prev->next = new;
	head->prev = new;
}

void list_add_tail_tcp(list_tcp new,list_tcp head)
{
	new->next = head;
	new->prev = head->prev;
	
	head->prev->next = new;
	head->prev = new;
}
/*
 *函数名：list_delete_tail
 *函数功能：将新节点链接到链表最后
 *参数：list new
 *返回值：void
 */
void list_delete_tail(list new)
{
	new->prev->next = new->next;
	new->next->prev = new->prev;

	new->next = NULL;
	new->prev = NULL;
	free(new);
}

void list_delete_tail_tcp(list_tcp new)
{
	new->prev->next = new->next;
	new->next->prev = new->prev;

	new->next = NULL;
	new->prev = NULL;
	free(new);
}
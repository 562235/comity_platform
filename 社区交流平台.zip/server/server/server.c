#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h> 
#include <sys/types.h>          /* See NOTES */
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <strings.h>
#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "list.h"


//创建头结点
list head;
list_tcp head_tcp;
/*
 *函数功能：将上线的用户加入到链表中。还有承担转发消息的功能
 *
 */
void *msg_tran(void *arg)
{
    list p = head;
    list_tcp p_tcp = head_tcp;
    int udp_socket = *((int *)arg);
    //存放用户地址信息
    struct sockaddr_in user_addr, talk_obj_addr;
    int size = sizeof(user_addr);
    //设置广播地址  192.168.94.255  or  255.255.255.255 
    struct sockaddr_in   bro_addr; 
    bro_addr.sin_family  = AF_INET;
    bro_addr.sin_port    =  htons(9898); 
    bro_addr.sin_addr.s_addr = inet_addr("255.255.255.255");
    while(1)
    {
        //buf用来存放用户发来的整个数据
        char buf[4096] = {0};
        //存放消息的类型
        char type[1024] = {0};
        //存放消息的具体内容
        char msg[1024] = {0};
        //接收并打印信息
        recvfrom(udp_socket, buf, 4096, 0, (struct sockaddr *)&user_addr, &size);
       // printf("IP=%s, port=%d, %s\n", inet_ntoa(user_addr.sin_addr), ntohs(user_addr.sin_port), buf);
        //分割数据,type用来分辨是什么情况，msg存放内容
        sscanf(buf, "type=%s msg=%s", type, msg);
        //printf("type = %s, name = %s\n", type, msg);
        //如果是上线，将用户加入到链表中
        if(strcmp(type, "shangxian") == 0)
        {
            //将用户的ip地址、名字、端口存放至链表中
            list new = newNode(inet_ntoa(user_addr.sin_addr), msg, ntohs(user_addr.sin_port));
            list_add_tail(new, head);
            printf("%s上线了\n", msg);
            p = head->next;
            printf("-------------------------------\n");
            while(p != head)
            {
                printf("当前在线:");
                printf("IP=%s, port=%d, %s\n", p->user_ip, p->port, p->user_name);
                p = p->next;
            }
            printf("-------------------------------\n");
        }
        //如果是上线，将用户从链表中删除
        if(strcmp(type, "xiaxian") == 0)
        {
            p = head->next;
            //在链表中遍历，找到用户的ip
            while(strcmp(p->user_ip, inet_ntoa(user_addr.sin_addr)) != 0)
            {
                p = p->next;
                if(p == head)
                {
                    printf("用户根本不在线\n");
                    break;
                }
            }
            if( p == head)
                continue;
            list_delete_tail(p);
            printf("%s下线了\n", msg);
            printf("-------------------------------\n");
            p = head->next;
            while(p != head)
            {
                printf("当前在线:");
                printf("IP=%s, port=%d, %s\n", p->user_ip, p->port, p->user_name);
                p = p->next;
            }
            printf("-------------------------------\n");
        }
        //如果是请求访问在线列表，则发送过去 
        if(strcmp(type, "request_list") == 0)
        {
            printf("-------------------------------\n");
            printf("%s请求访问在线列表\n", msg);
            char name_room[1024] = {0};
            //记录在线人数
            int i = 0;
            //从第一个节点开始访问,将链表中所有在线的用户名传过去
            p = head->next;
            strcat(name_room, p->user_name);
            i++;
            p = p->next;
            while(p != head)
            {
                
                strcat(name_room, "&");
                strcat(name_room, p->user_name);
                i++;
                p = p->next;
            }
            
            //将整个信息拼接到buf中
            bzero(buf, 4096);
            sprintf(buf, "type=back_user_list msg=%s num=%d", name_room, i);
            printf("%s\n", name_room);
           //设置对方地址信息
            struct sockaddr_in   talk_addr; 
            talk_addr.sin_family  = AF_INET;
            talk_addr.sin_port    =  htons(ntohs(user_addr.sin_port)); 
            talk_addr.sin_addr.s_addr = inet_addr(inet_ntoa(user_addr.sin_addr));
            //发送信息到广播中
            sendto(udp_socket, buf, strlen(buf), 0, (struct sockaddr *)&talk_addr, sizeof(talk_addr));
            sleep(1);
            sendto(udp_socket, buf, strlen(buf), 0, (struct sockaddr *)&talk_addr, sizeof(talk_addr));
            printf("已发送在线列表\n");
            printf("-------------------------------\n");
        }
        //转发聊天内容
        if(strcmp(type, "talk_msg") == 0)
        {
            printf("-------------------------------\n");
            //用来存放通信对象的名字
            char talk_obj[100] = {0};
            char obj_flag[100] = {0};
            //用来存放聊天内容
            char talk_msg[1024] = {0};
            printf("%s\n", msg);
            //分割msg，talk_obj存放通信对象名，talk_msg存放通信内容
            char *flag = strdup(msg);
            strcpy(talk_msg, strsep(&flag, "&"));
            strcpy(obj_flag, strsep(&flag, "&"));
            free(flag);
            sscanf(obj_flag, "obj=%s", talk_obj);
            //找到通信人名字
            list own_p = head->next;
            while(own_p != head)
            {
                if(strcmp(own_p->user_ip, inet_ntoa(user_addr.sin_addr)) == 0)
                    break;
                own_p = own_p->next;
            }
            
            //在链表中找到通信对象的名字
            p = head->next;
            
            while(p != head)
            {
                if(strcmp(p->user_name, talk_obj) == 0)
                    break;
                p = p->next;
            }
            //找到通信对象的sockfd
            p_tcp = head_tcp->next;
            while(p_tcp != head_tcp)
            {
                if(strcmp(p->user_ip, p_tcp->user_ip) == 0)
                    break;
                p_tcp = p_tcp->next;
            }
            //设置对象地址信息
            talk_obj_addr.sin_family  = AF_INET;
            talk_obj_addr.sin_port    =  htons(p_tcp->port); 
            talk_obj_addr.sin_addr.s_addr = inet_addr(p_tcp->user_ip);
            //清空buf
            bzero(buf, 4096);
            //拼接整体信息
            sprintf(buf, "type=chat_message msg=%s对你说:%s", own_p->user_name, talk_msg);
            printf("%s,%s\n", buf, p_tcp->user_ip);
            //发送信息到对象
            write(p_tcp->sockfd, buf, strlen(buf));
            printf("-------------------------------\n");
        }

    }
    

}

void *tcp_accept(void *arg)
{
    //创建一个TCPsocket
    int tcp_socket;
    tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
    if(tcp_socket < 0)
    {
        perror("Create socket failed ");
        return NULL;
    }
    //获取一个头结点
    head_tcp = init_list_tcp();
    //开启地址复用功能  
    int on=1; //开启
    int ret = setsockopt(tcp_socket,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(on));
    if(ret < 0)
    {
        perror("");
        return NULL;
    }
    else
    {
        printf("开启端口复用成功\n");
             
    }
    //设置tcp服务器地址信息
    struct sockaddr_in serveraddr,clientaddr;
    serveraddr.sin_family = AF_INET;               //IPV4的协议族
    serveraddr.sin_addr.s_addr = inet_addr("0.0.0.0");       //任何IPV4的地址都可以链接
    serveraddr.sin_port = htons(8989);
    int size = sizeof(serveraddr);

    ret = bind(tcp_socket, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
    if(ret < 0)
    {
        perror("bind failed: ");
        close(tcp_socket);
        return NULL;
    }

    ret = listen(tcp_socket, 20);
    if(ret < 0)
    {
        perror("listen failed: ");
        close(tcp_socket);
        return NULL;
    }
    while(1)
    {
        //每进来一个连接就加入到链表中
        int new_socket=accept(tcp_socket,(struct sockaddr *)&clientaddr, &size);
        if(new_socket < 0 )
        {
            perror("accept failed");
            return NULL;
        }
        list_tcp new = newNode_tcp(inet_ntoa(clientaddr.sin_addr), new_socket, ntohs(clientaddr.sin_port));
        list_add_tail_tcp(new, head_tcp);
        printf("tcp连接成功\n");
    }
    
}


int main(int argc, char const *argv[])
{
	//创建UDP 通信socket  
    int udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
	if(udp_socket < 0)
	{
		perror("udp_socket create failed");
		return -1;
	}

	//创建TCP 通信socket
	int tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
	if(tcp_socket < 0)
	{
		perror("tcp_socket create failed");
		return -1;
	} 
    int on=1; //开启广播
    int ret = setsockopt(udp_socket,SOL_SOCKET,SO_BROADCAST,&on,sizeof(on));
        if(ret <0)
        {
            perror("广播失败：");
            return -1;
        }
        else
            printf("开启广播成功\n");
        
	//udp通信的地址信息及大小 UDP端口9898
	struct sockaddr_in   udp_addr; 
    udp_addr.sin_family  = AF_INET;
    udp_addr.sin_port    = htons(9898); 
    udp_addr.sin_addr.s_addr = inet_addr("0.0.0.0");
    int size = sizeof(udp_addr);
   
    //3.设置广播地址  192.168.94.255  or  255.255.255.255 
    struct sockaddr_in   bro_addr; 
    bro_addr.sin_family  = AF_INET;
    bro_addr.sin_port    =  htons(9898); 
    bro_addr.sin_addr.s_addr = inet_addr("255.255.255.255");


	//在网络中注册udp地址
    ret = bind(udp_socket, (struct sockaddr *)&udp_addr, sizeof(udp_addr));
	if(ret == -1)
    {
    	perror("udp bind failed");
    	return -1;
    }

    //获取一个头结点
    head = init_list();
    //创建一个线程，不断接收组播中的数据，判断服务器该做什么（主要用于转发聊天消息和更新用户列表）
    pthread_t pid, pid1;
    pthread_create(&pid, NULL, msg_tran, (void *)&udp_socket);
    //创建一个线程，不断获取连接的tcp客户端信息
    pthread_create(&pid, NULL, tcp_accept, NULL);
    //存放服务器发给用户的整个信息
    char server_msg[4096] ={0};
    while(1)
    {
    	int a = 0;
    	printf("请输入选项1.发送通知 2.广告更新\n");
        fflush(stdin);
        if(scanf("%d", &a) != 1)
        {
            printf("请输入1或者2\n");
            continue;
        }
    	//a等于1时，向广播中发送通知信息。让用户显示通知
    	if(a == 1)
    	{
            printf("-------------------------------\n");
    		bzero(server_msg, 4096);
            //buf用来存放通知内容
    		char buf[1024] = {0};
            printf("请输入通知内容\n");
            fflush(stdin);
    		scanf("%s", buf);
    		sprintf(server_msg, "type=inform msg=%s", buf);
    		//将通知类型的数据发到广播中
    		sendto(udp_socket, server_msg, strlen(server_msg), 0, (struct sockaddr *)&bro_addr, sizeof(bro_addr));
            sendto(udp_socket, server_msg, strlen(server_msg), 0, (struct sockaddr *)&bro_addr, sizeof(bro_addr));
            printf("通知已发送\n");  
            printf("-------------------------------\n");
    	}
        if(a == 2)
        {
            printf("-------------------------------\n");
            bzero(server_msg, 4096);
            //存放更新的图片名
            char pic_name[100];
            printf("请输入图片名\n");
            fflush(stdin);
            scanf("%s", pic_name);
            sprintf(server_msg, "type=pic_updata msg=%s", pic_name);
            //将图片更新类型的数据发到广播中
            sendto(udp_socket, server_msg, strlen(server_msg), 0, (struct sockaddr *)&bro_addr, sizeof(bro_addr));
            sendto(udp_socket, server_msg, strlen(server_msg), 0, (struct sockaddr *)&bro_addr, sizeof(bro_addr));
            printf("图片已更新\n");
            printf("-------------------------------\n");
        }

    }

	return 0;
}